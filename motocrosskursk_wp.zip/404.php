
<?php get_header(); ?>

<?php get_template_part('template-parts/header-section');?>

	<main id="primary" class="page site-main">

	<div class = "content contentInPage centrElem">	 
		<div class="_container">
			<h1 class = "h404">404</h1>
				Запрашиваемая страница не была найдена
		</div>
	</div>

	</main>

<?php get_footer(); ?>